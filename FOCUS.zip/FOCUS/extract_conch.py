import torch
from conch.open_clip_custom.factory import create_model_from_pretrained

# load model (same cách bạn đang dùng)
model_cfg = 'conch_ViT-B-16'
model, preprocess = create_model_from_pretrained(model_cfg, 'ckpts/conch.pth')
model.eval()

# tạo input dummy đúng kích thước (ví dụ 1x3x224x224)
dummy = torch.randn(1, 3, 224, 224)

# trace (nếu model không có control-flow phức tạp)
traced = torch.jit.trace(model.encode_image, dummy)
traced.save("conch.pt")
