import os
import pandas as pd
import numpy as np
import torch
from pyspark import SparkContext, SparkConf

# ---------------- Reduce Function ----------------
def reduce_features(features_list):
    feats = [f for f in features_list if f is not None]
    if len(feats) == 0:
        return None
    if len(feats) == 1:
        return feats[0]
    arr = np.array(feats)
    return arr.mean(axis=0).tolist()

# ---------------- Map Function ----------------
def extract_with_model(x, ckpt_path):
    try:
        from feature_extractor import FeatureExtractor
        slide_id, img_path = x
        extractor = FeatureExtractor(ckpt_path=ckpt_path)
        feat = extractor.extract_features(img_path)
        print(f"✅ Extracted features for {slide_id}")
        return (slide_id, feat)
    except Exception as e:
        print(f"❌ Error processing {x}: {e}")
        return (x[0], None)

# ---------------- Main Pipeline ----------------
def main(csv_path, source_folder, output_csv, features_dir, ckpt_path="ckpts/conch.pth"):
    # Spark config (tăng memory một chút)
    conf = SparkConf().setAppName("FeatureMapReduce") \
                      .set("spark.driver.memory", "6g") \
                      .set("spark.executor.memory", "4g")
    sc = SparkContext(conf=conf)

    # Đọc metadata
    df = pd.read_csv(csv_path)
    slide_ids = df['image_id'].tolist()
    image_paths = [os.path.join(source_folder, f"{sid}.jpg") for sid in slide_ids]
    print(f"📂 Loaded {len(slide_ids)} slide IDs from {csv_path}")

    # Tạo thư mục lưu .pt
    os.makedirs(features_dir, exist_ok=True)

    # Tạo RDD
    rdd = sc.parallelize(zip(slide_ids, image_paths), numSlices=4)

    # Map (load model trong worker)
    mapped = rdd.map(lambda x: extract_with_model(x, ckpt_path))

    # Shuffle & Reduce
    reduced = mapped.groupByKey().mapValues(lambda feats: reduce_features(list(feats)))

    # Collect kết quả
    results = reduced.collect()
    print(f"📊 Collected {len(results)} feature vectors")

    # Lưu CSV
    df_out = pd.DataFrame(results, columns=["image_id", "features"])
    df_out.to_csv(output_csv, index=False)
    print(f"✅ Saved global features to {output_csv}")

    # Lưu từng ảnh thành .pt
    for slide_id, feat in results:
        if feat is not None:
            out_path = os.path.join(features_dir, f"{slide_id}.pt")
            torch.save(torch.tensor(feat, dtype=torch.float32), out_path)
    print(f"✅ Saved individual .pt files in {features_dir}")

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--csv_path", type=str, required=True)
    parser.add_argument("--source_folder", type=str, required=True)
    parser.add_argument("--output_csv", type=str, required=True)
    parser.add_argument("--features_dir", type=str, required=True)
    parser.add_argument("--ckpt_path", type=str, default="ckpts/conch.pth")
    args = parser.parse_args()

    main(
        csv_path=args.csv_path,
        source_folder=args.source_folder,
        output_csv=args.output_csv,
        features_dir=args.features_dir,
        ckpt_path=args.ckpt_path
    )


# map_reduce_features.py
# import argparse
# import torch
# import numpy as np
# import os


# from PIL import Image
# from conch.open_clip_custom.factory import create_model_from_pretrained

# Image.MAX_IMAGE_PIXELS = None

# class FeatureExtractor:
#     def __init__(self, ckpt_path="ckpts/conch.pth", device=None):
#         self.device = device or ('cuda' if torch.cuda.is_available() else 'cpu')
#         model_cfg = 'conch_ViT-B-16'
#         self.model, self.preprocess = create_model_from_pretrained(
#             model_cfg, ckpt_path, device=self.device
#         )
#         self.model.eval()

#     def extract_features(self, image_path):
#         try:
#             image = Image.open(image_path).convert("RGB")
#             tensor = self.preprocess(image).unsqueeze(0).to(self.device)
#             with torch.no_grad():
#                 feat = self.model.encode_image(tensor)
#                 return feat.squeeze(0).cpu().numpy().tolist()
#         except Exception as e:
#             print(f"⚠️ Error {image_path}: {str(e)}")
#             return None



# def main():
#     parser = argparse.ArgumentParser()
#     parser.add_argument("--image_id", type=str, required=True)
#     parser.add_argument("--image_path", type=str, required=True)
#     parser.add_argument("--ckpt_path", type=str, required=True)
#     args = parser.parse_args()

#     try:
#         extractor = FeatureExtractor(ckpt_path=args.ckpt_path)
#         feat = extractor.extract_features(args.image_path)
#         feat = np.array(feat, dtype=np.float32)

#         # In ra dạng CSV: "f1,f2,f3,..."
#         print(",".join([str(x) for x in feat]))
#     except Exception as e:
#         print(f"ERROR: {e}", flush=True)

# if __name__ == "__main__":
#     main()




# import argparse
# import torch
# import numpy as np
# import os
# import sys
# from PIL import Image
# from conch.open_clip_custom.factory import create_model_from_pretrained

# # Thêm PYTHONPATH để import được các thư viện đã upload
# current_dir = os.path.dirname(os.path.abspath(__file__))
# sys.path.insert(0, current_dir)
# sys.path.insert(0, os.path.join(current_dir, 'python_libs'))

# Image.MAX_IMAGE_PIXELS = None

# class FeatureExtractor:
#     def __init__(self, ckpt_path="ckpts/conch.pth", device=None):
#         self.device = device or ('cuda' if torch.cuda.is_available() else 'cpu')
#         model_cfg = 'conch_ViT-B-16'
#         self.model, self.preprocess = create_model_from_pretrained(
#             model_cfg, ckpt_path, device=self.device
#         )
#         self.model.eval()
        
#     def extract_features_from_patch(self, image_patch):
#         """Trích xuất đặc trưng từ 1 patch PIL.Image."""
#         tensor = self.preprocess(image_patch).unsqueeze(0).to(self.device)
#         with torch.no_grad():
#             feat = self.model.encode_image(tensor)
#         return feat.squeeze(0).cpu().numpy()
        
#     def extract_features(self, image_path, patch_size=512, aggregate="mean"):
#         """
#         Trích xuất đặc trưng từ ảnh lớn bằng cách tách thành patch_size x patch_size.
#         aggregate: "mean" hoặc "concat"
#         """
#         try:
#             # Kiểm tra nếu là HDFS path
#             if image_path.startswith('hdfs://'):
#                 # Sử dụng hdfs3 hoặc subprocess để đọc file từ HDFS
#                 import subprocess
#                 result = subprocess.run(['hdfs', 'dfs', '-cat', image_path], 
#                                       capture_output=True)
#                 if result.returncode == 0:
#                     from io import BytesIO
#                     image = Image.open(BytesIO(result.stdout)).convert("RGB")
#                 else:
#                     raise Exception(f"Cannot read from HDFS: {image_path}")
#             else:
#                 image = Image.open(image_path).convert("RGB")
                
#             width, height = image.size
#             features = []
            
#             for top in range(0, height, patch_size):
#                 for left in range(0, width, patch_size):
#                     right = min(left + patch_size, width)
#                     bottom = min(top + patch_size, height)
#                     patch = image.crop((left, top, right, bottom))
#                     feat = self.extract_features_from_patch(patch)
#                     features.append(feat)
                    
#             features = np.stack(features, axis=0)
            
#             if aggregate == "mean":
#                 return features.mean(axis=0).tolist()
#             elif aggregate == "concat":
#                 return features.flatten().tolist()
#             else:
#                 raise ValueError(f"Unknown aggregate mode: {aggregate}")
                
#         except Exception as e:
#             print(f"⚠️ Error {image_path}: {str(e)}")
#             return None

# def main():
#     parser = argparse.ArgumentParser()
#     parser.add_argument("--image_id", type=str, required=True)
#     parser.add_argument("--image_path", type=str, required=True)
#     parser.add_argument("--ckpt_path", type=str, required=True)
#     parser.add_argument("--patch_size", type=int, default=512)
#     parser.add_argument("--aggregate", type=str, default="mean", choices=["mean", "concat"])
    
#     args = parser.parse_args()
    
#     try:
#         extractor = FeatureExtractor(ckpt_path=args.ckpt_path)
#         feat = extractor.extract_features(args.image_path, 
#                                         patch_size=args.patch_size, 
#                                         aggregate=args.aggregate)
        
#         if feat is not None:
#             feat = np.array(feat, dtype=np.float32)
#             # Output format: image_id,feature1,feature2,...
#             output = f"{args.image_id}," + ",".join([str(x) for x in feat])
#             print(output)
#         else:
#             print(f"{args.image_id},ERROR")
            
#     except Exception as e:
#         print(f"{args.image_id},ERROR: {e}", flush=True)

# if __name__ == "__main__":
#     main()




# import os
# import pandas as pd
# import numpy as np
# import torch
# from pyspark import SparkContext, SparkConf, TaskContext
# # import torchvision.models as models
# from conch.open_clip_custom.factory import create_model_from_pretrained
# import openslide

# # ---------------- Reduce Function ----------------
# def reduce_features(features_list):
#     feats = [f for f in features_list if f is not None]
#     if len(feats) == 0:
#         return None
#     if len(feats) == 1:
#         return feats[0]
#     arr = np.array(feats)
#     return arr.mean(axis=0).tolist()


# from PIL import Image, ImageFile
# Image.MAX_IMAGE_PIXELS = None
# ImageFile.LOAD_TRUNCATED_IMAGES = True
# # ---------------- Feature Extractor ----------------
# class FeatureExtractor:
#     def __init__(self, ckpt_path="ckpts/conch.pth", device=None):
#         self.device = device or ('cuda' if torch.cuda.is_available() else 'cpu')
#         model_cfg = 'conch_ViT-B-16'
#         self.model, self.preprocess = create_model_from_pretrained(
#             model_cfg, ckpt_path, device=self.device
#         )
#         self.model.eval()

#     def preprocess(self, img):
#         """Chuyển PIL image -> tensor chuẩn hóa"""
#         from torchvision import transforms
#         tfm = transforms.Compose([
#             transforms.Resize((224, 224)),   # thay đổi theo input model
#             transforms.ToTensor(),
#             transforms.Normalize(mean=[0.485, 0.456, 0.406],
#                                  std=[0.229, 0.224, 0.225])
#         ])
#         return tfm(img).unsqueeze(0)

#     def extract_features(self, img):
#         """Extract feature cho 1 patch"""
#         with torch.no_grad():
#             tensor = self.preprocess(img).to(self.device)
#             if hasattr(self.model, "encode_image"):
#                 feat = self.model.encode_image(tensor)
#             else:
#                 feat = self.model(tensor)
#             return feat.cpu().numpy()

#     # def extract_from_patches(self, img_path, patch_size=512):
#     #     """Chia ảnh thành patch 512x512 và lấy mean feature"""
#     #     img = Image.open(img_path).convert("RGB")
#     #     W, H = img.size
#     #     feats = []

#     #     for y in range(0, H, patch_size):
#     #         for x in range(0, W, patch_size):
#     #             patch = img.crop((x, y, min(x + patch_size, W), min(y + patch_size, H)))
#     #             feat = self.extract_features(patch)
#     #             feats.append(feat)

#     #     if len(feats) == 0:
#     #         return None
#     #     arr = np.vstack(feats)
#     #     return arr.mean(axis=0).tolist()
#     def extract_from_patches(self, img_path, patch_size=512, level=0):

#         feats = []
#         with Image.open(img_path) as img:
#                 W, H = img.size
#                 for y in range(0, H, patch_size):
#                     for x in range(0, W, patch_size):
#                         box = (x, y, min(x + patch_size, W), min(y + patch_size, H))
#                         patch = img.crop(box).convert("RGB")
#                         feats.append(self.extract_features(patch))

#         if len(feats) == 0:
#             return None
#         arr = np.vstack(feats)
#         return arr.mean(axis=0).tolist()

# # ---------------- Map Function ----------------
# def extract_with_model(x, ckpt_path, gpu_id=None):
#     try:
#         slide_id, img_path = x
#         device = f"cuda:{gpu_id}" if torch.cuda.is_available() else "cpu"
#         extractor = FeatureExtractor(ckpt_path=ckpt_path, device=device)

#         feat = extractor.extract_from_patches(img_path, patch_size=512)

#         print(f"✅ Extracted features for {slide_id} on {device}")
#         return (slide_id, feat)
#     except Exception as e:
#         print(f"❌ Error processing {x}: {e}")
#         return (x[0], None)


# def map_with_gpu(x, ckpt_path):
#     # gán GPU theo partition ID
#     task_id = TaskContext.get().partitionId()
#     gpu_id = task_id % 2   # 2 GPU: cuda:0 và cuda:1
#     return extract_with_model(x, ckpt_path, gpu_id=gpu_id)


# # ---------------- Main Pipeline ----------------
# def main(csv_path, source_folder, output_csv, features_dir, ckpt_path="ckpts/conch.pth"):
#     # Spark config
#     conf = SparkConf().setAppName("FeatureMapReduce") \
#                       .set("spark.driver.memory", "6g") \
#                       .set("spark.executor.memory", "4g")
#     sc = SparkContext(conf=conf)

#     # Đọc metadata
#     df = pd.read_csv(csv_path)
#     slide_ids = df['image_id'].tolist()
#     image_paths = [os.path.join(source_folder, f"{sid}.jpg") for sid in slide_ids]
#     print(f"📂 Loaded {len(slide_ids)} slide IDs from {csv_path}")

#     # Tạo thư mục lưu .pt
#     os.makedirs(features_dir, exist_ok=True)

#     # Tạo RDD
#     rdd = sc.parallelize(zip(slide_ids, image_paths), numSlices=8)

#     # Map (multi-GPU)
#     mapped = rdd.map(lambda x: map_with_gpu(x, ckpt_path))

#     # Shuffle & Reduce
#     reduced = mapped.groupByKey().mapValues(lambda feats: reduce_features(list(feats)))

#     # Collect kết quả
#     results = reduced.collect()
#     print(f"📊 Collected {len(results)} feature vectors")

#     # Lưu CSV
#     df_out = pd.DataFrame(results, columns=["image_id", "features"])
#     df_out.to_csv(output_csv, index=False)
#     print(f"✅ Saved global features to {output_csv}")

#     # Lưu từng ảnh thành .pt
#     for slide_id, feat in results:
#         if feat is not None:
#             out_path = os.path.join(features_dir, f"{slide_id}.pt")
#             torch.save(torch.tensor(feat, dtype=torch.float32), out_path)
#     print(f"✅ Saved individual .pt files in {features_dir}")


# if __name__ == "__main__":
#     import argparse
#     parser = argparse.ArgumentParser()
#     parser.add_argument("--csv_path", type=str, required=True)
#     parser.add_argument("--source_folder", type=str, required=True)
#     parser.add_argument("--output_csv", type=str, required=True)
#     parser.add_argument("--features_dir", type=str, required=True)
#     parser.add_argument("--ckpt_path", type=str, default="ckpts/conch.pth")
#     args = parser.parse_args()

#     main(
#         csv_path=args.csv_path,
#         source_folder=args.source_folder,
#         output_csv=args.output_csv,
#         features_dir=args.features_dir,
#         ckpt_path=args.ckpt_path
#     )
