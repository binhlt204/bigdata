from __future__ import print_function, division
import os
import torch
import torch.nn as nn
import torchvision.transforms as transforms
from PIL import Image
import pandas as pd
import numpy as np
from pathlib import Path
from tqdm import tqdm
import argparse
import gc
import warnings
from concurrent.futures import ThreadPoolExecutor
import multiprocessing as mp
from torch.utils.data import DataLoader, Dataset

# Suppress PIL warnings for large images
warnings.filterwarnings("ignore", category=UserWarning)
Image.MAX_IMAGE_PIXELS = None

class ImageDataset(Dataset):
    """Custom dataset for batch processing"""
    def __init__(self, image_paths, preprocess_fn):
        self.image_paths = image_paths
        self.preprocess_fn = preprocess_fn
        
    def __len__(self):
        return len(self.image_paths)
        
    def __getitem__(self, idx):
        image_path = self.image_paths[idx]
        try:
            image = Image.open(image_path).convert('RGB')
            processed_image = self.preprocess_fn(image)
            return processed_image, image_path
        except Exception as e:
            print(f"Error loading {image_path}: {e}")
            # Return None image and path for error handling
            return None, image_path

def collate_fn(batch):
    """Custom collate function to handle None images"""
    valid_batch = [(img, path) for img, path in batch if img is not None]
    if not valid_batch:
        return torch.tensor([]), []
    
    images, paths = zip(*valid_batch)
    return torch.stack(images), list(paths)

class OptimizedFeatureExtractor:
    def __init__(self, args, device='cuda' if torch.cuda.is_available() else 'cpu'):
        self.args = args
        self.device = device
        self.batch_size = getattr(args, 'batch_size', 32)
        
        print(f"Using device: {device}")
        print(f"Batch size: {self.batch_size}")
        
        # Initialize model - using ResNet50 as fallback since conch import might fail
        self.model, self.preprocess = self._load_model()
        self.model.eval()
        
        # Enable mixed precision for speed
        self.use_amp = torch.cuda.is_available()
        if self.use_amp:
            self.scaler = torch.cuda.amp.GradScaler()
    
    def _load_model(self):
        """Load model with fallback options"""
        try:
            # Try to load CONCH model
            from conch.open_clip_custom.factory import create_model_from_pretrained
            model_cfg = 'conch_ViT-B-16'
            checkpoint_path = 'ckpts/conch.pth'
            model, preprocess = create_model_from_pretrained(
                model_cfg, checkpoint_path, device=self.device
            )
            print("Loaded CONCH model successfully")
            return model, preprocess
        except ImportError:
            print("CONCH not available, using ResNet50")
            return self._load_resnet50()
    
    def _load_resnet50(self):
        """Fallback to ResNet50"""
        import torchvision.models as models
        model = models.resnet50(pretrained=True)
        model = nn.Sequential(*list(model.children())[:-1])  # Remove classifier
        model = model.to(self.device)
        
        preprocess = transforms.Compose([
            transforms.Resize((224, 224)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], 
                               std=[0.229, 0.224, 0.225])
        ])
        return model, preprocess
    
    def extract_features_batch(self, image_paths, output_dir):
        """Extract features in batches for efficiency"""
        Path(output_dir).mkdir(parents=True, exist_ok=True)
        
        # Filter existing files to avoid reprocessing
        image_paths = self._filter_existing_files(image_paths, output_dir)
        
        if not image_paths:
            print("All features already extracted!")
            return
        
        print(f"Processing {len(image_paths)} images...")
        
        # Create dataset and dataloader
        dataset = ImageDataset(image_paths, self.preprocess)
        dataloader = DataLoader(
            dataset, 
            batch_size=self.batch_size,
            shuffle=False,
            num_workers=min(4, mp.cpu_count()),
            pin_memory=torch.cuda.is_available(),
            collate_fn=collate_fn
        )
        
        with torch.no_grad():
            for batch_images, batch_paths in tqdm(dataloader, desc="Extracting features"):
                if len(batch_images) == 0:  # Skip empty batches
                    continue
                    
                batch_images = batch_images.to(self.device, non_blocking=True)
                
                try:
                    if self.use_amp:
                        with torch.cuda.amp.autocast():
                            if hasattr(self.model, 'encode_image'):
                                features = self.model.encode_image(batch_images)
                            else:
                                features = self.model(batch_images)
                    else:
                        if hasattr(self.model, 'encode_image'):
                            features = self.model.encode_image(batch_images)
                        else:
                            features = self.model(batch_images)
                    
                    # Move to CPU and save
                    features = features.cpu()
                    
                    # Save individual features
                    for i, image_path in enumerate(batch_paths):
                        slide_id = Path(image_path).stem
                        output_path = os.path.join(output_dir, f"{slide_id}.pt")
                        torch.save(features[i], output_path)
                        
                except Exception as e:
                    print(f"Error processing batch: {e}")
                    continue
                
                # Clear GPU cache periodically
                if torch.cuda.is_available():
                    torch.cuda.empty_cache()
    
    def _filter_existing_files(self, image_paths, output_dir):
        """Filter out images that already have extracted features"""
        filtered_paths = []
        
        for image_path in image_paths:
            slide_id = Path(image_path).stem
            output_path = os.path.join(output_dir, f"{slide_id}.pt")
            
            if not os.path.exists(output_path):
                if os.path.exists(image_path):  # Only include if source exists
                    filtered_paths.append(image_path)
                else:
                    print(f"Warning: Source image not found: {image_path}")
            
        print(f"Filtered: {len(image_paths) - len(filtered_paths)} already processed")
        return filtered_paths
    
    def process_memory_efficient(self, wsi_data, source_folder, output_dir):
        """Process with memory management"""
        
        # Get all image paths
        image_paths = []
        missing_files = []
        
        for slide_id in wsi_data['slide_id'].tolist():
            # Try different extensions
            for ext in ['.png', '.jpg', '.jpeg', '.tiff', '.tif']:
                image_path = os.path.join(source_folder, f"{slide_id}{ext}")
                if os.path.exists(image_path):
                    image_paths.append(image_path)
                    break
            else:
                missing_files.append(slide_id)
        
        if missing_files:
            print(f"Warning: {len(missing_files)} images not found")
            print("Missing files:", missing_files[:10])  # Show first 10
        
        print(f"Found {len(image_paths)} images to process")
        
        # Process in batches
        self.extract_features_batch(image_paths, output_dir)
        
        # Clean up
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
        gc.collect()

def main(args):
    """Main function with argument validation"""
    
    # Validate inputs
    if not os.path.exists(args.csv_path):
        raise FileNotFoundError(f"CSV file not found: {args.csv_path}")
    
    if not os.path.exists(args.source_folder):
        raise FileNotFoundError(f"Source folder not found: {args.source_folder}")
    
    # Load CSV
    try:
        wsi_data = pd.read_csv(args.csv_path)
        if 'slide_id' not in wsi_data.columns:
            raise ValueError("CSV must contain 'slide_id' column")
        print(f"Loaded {len(wsi_data)} slides from CSV")
    except Exception as e:
        raise ValueError(f"Error reading CSV: {e}")
    
    # Initialize extractor
    extractor = OptimizedFeatureExtractor(args)
    
    # Process images
    extractor.process_memory_efficient(
        wsi_data=wsi_data,
        source_folder=args.source_folder,
        output_dir=args.data_folder
    )
    
    print("Feature extraction completed!")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Optimized Feature Extraction')
    parser.add_argument('--csv_path', type=str, required=True, 
                       help='CSV file with slide_id column')
    parser.add_argument('--source_folder', type=str, required=True, 
                       help='Folder containing images')
    parser.add_argument('--data_folder', type=str, required=True, 
                       help='Output directory for features')
    parser.add_argument('--batch_size', type=int, default=16, 
                       help='Batch size for processing')
    
    args = parser.parse_args()
    main(args)